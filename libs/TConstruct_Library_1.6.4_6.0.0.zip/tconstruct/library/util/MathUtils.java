package tconstruct.library.util;

public class MathUtils
{
    /**
     * finds smaller of 2 valid int's
     * based on COFH's minI method
     */
    public static int minInt (int a, int b)
    {

        return a < b ? a : b;
    }
}
